#include <stdlib.h>
#include <time.h>

void seed();
int int_random(int min, int max);
double double_random(double min, double max);