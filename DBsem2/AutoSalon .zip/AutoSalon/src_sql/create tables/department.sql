-- ****************** SqlDBM: MySQL ******************;
-- ***************************************************;


-- ************************************** `department`

CREATE TABLE `department`
(
 `id_department` INT NOT NULL AUTO_INCREMENT ,
 `name`          VARCHAR(45) NOT NULL ,
 `address`       VARCHAR(45) NOT NULL ,
 `shef`          VARCHAR(45) NOT NULL ,

PRIMARY KEY (`id_department`)
);





