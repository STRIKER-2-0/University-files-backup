-- ****************** SqlDBM: MySQL ******************;
-- ***************************************************;


-- ************************************** `petrol_type`

CREATE TABLE `petrol_type`
(
 `id_petrol`   INT NOT NULL AUTO_INCREMENT ,
 `petrol_type` VARCHAR(20) NOT NULL ,

PRIMARY KEY (`id_petrol`)
);





