-- ****************** SqlDBM: MySQL ******************;
-- ***************************************************;


-- ************************************** `business_type`

CREATE TABLE `business_type`
(
 `id_type`   INT NOT NULL AUTO_INCREMENT ,
 `name_type` VARCHAR(15) NOT NULL ,

PRIMARY KEY (`id_type`)
);





