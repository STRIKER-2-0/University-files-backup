-- ****************** SqlDBM: MySQL ******************;
-- ***************************************************;


-- ************************************** `auto_mark`

CREATE TABLE `auto_mark`
(
 `id_mark`   INT NOT NULL AUTO_INCREMENT ,
 `name_mark` VARCHAR(45) NOT NULL ,

PRIMARY KEY (`id_mark`)
);





