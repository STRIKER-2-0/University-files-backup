-- ****************** SqlDBM: MySQL ******************;
-- ***************************************************;


-- ************************************** `type_drive`

CREATE TABLE `type_drive`
(
 `id_type_drive` INT NOT NULL AUTO_INCREMENT ,
 `type_drive`    VARCHAR(15) NOT NULL ,

PRIMARY KEY (`id_type_drive`)
);





