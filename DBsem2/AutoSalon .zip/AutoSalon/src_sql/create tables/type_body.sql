-- ****************** SqlDBM: MySQL ******************;
-- ***************************************************;


-- ************************************** `type_body`

CREATE TABLE `type_body`
(
 `id_type_body` INT NOT NULL AUTO_INCREMENT ,
 `type_body`    VARCHAR(45) NOT NULL ,

PRIMARY KEY (`id_type_body`)
);





