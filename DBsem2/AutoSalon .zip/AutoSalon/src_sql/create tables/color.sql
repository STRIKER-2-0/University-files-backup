-- ****************** SqlDBM: MySQL ******************;
-- ***************************************************;


-- ************************************** `color`

CREATE TABLE `color`
(
 `id_color`   INT NOT NULL AUTO_INCREMENT ,
 `name_color` VARCHAR(45) NOT NULL ,

PRIMARY KEY (`id_color`)
);





