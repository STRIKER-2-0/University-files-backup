-- ****************** SqlDBM: MySQL ******************;
-- ***************************************************;


-- ************************************** `transmission_type`

CREATE TABLE `transmission_type`
(
 `id_transmission`   INT NOT NULL AUTO_INCREMENT ,
 `transmission_type` VARCHAR(20) NOT NULL ,

PRIMARY KEY (`id_transmission`)
);





