package tcpWork;

public class StopOperation extends CardOperation {

}
