package tcpWork;

import java.io.Serializable;

public abstract class CardOperation implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
