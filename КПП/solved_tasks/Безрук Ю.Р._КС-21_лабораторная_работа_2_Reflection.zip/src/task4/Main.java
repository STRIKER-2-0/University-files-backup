package task4;

public class Main{
	public static void main(String[] args) {		
		try {
			Object[] arr = ArrayCreator.toArray("check", 4, 2);
			System.out.println(ArrayCreator.toString(arr));
			arr=ArrayCreator.resizeArray(arr, 3, 1);
			System.out.println(ArrayCreator.toString(arr));
		} catch (IllegalDimensionCountException | InstantiationException | IllegalAccessException e) {
			e.printStackTrace();
		}
		
	}
}