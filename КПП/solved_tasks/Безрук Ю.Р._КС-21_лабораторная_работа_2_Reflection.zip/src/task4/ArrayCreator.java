package task4;
import java.lang.reflect.Array;
public class ArrayCreator {
	private static StringBuilder str;
	
	public static Object[] toArray(Object obj, int... dimensions) throws IllegalDimensionCountException, InstantiationException, IllegalAccessException{
		if(dimensions.length==0 || dimensions.length > 2) 
			throw new IllegalDimensionCountException();
		Object res[] = (Object[]) Array.newInstance(obj.getClass(), dimensions);
		for (int i = 0; i < res.length; i++) {
			if(res[i]!=null) {
				if(res[i].getClass().isArray()) {
					Object[] tmp = (Object[])res[i];
					for (int j = 0; j < tmp.length; j++) 
						tmp[j] = obj;
					continue;
				}
			}
			res[i] = obj;
		}
		return res;
	}
	public static Object[] resizeArray(Object[] arr, int... dimensions) {
  		if(dimensions.length<=0 || dimensions.length > 2) 
			throw new IllegalDimensionCountException();
		Class<?> c = arr.getClass();
		while(c.isArray())
			c=c.getComponentType();
		Object[] res = (Object[]) Array.newInstance(c, dimensions);
		if(!res.getClass().getComponentType().isArray())
			java.lang.System.arraycopy(arr, 0, res, 0, Math.min(res.length, arr.length));
		else {
			Object[] tmp = ((Object[])arr[0]);
			for (int i = 0; i < Math.min(res.length, arr.length); i++) {
				java.lang.System.arraycopy(arr[i], 0, res[i], 0, Math.min(dimensions[1], tmp.length ));
			}
		}
		return res;		
	}
	public static String toString(Object[] arr) {
		Class<?> c = arr.getClass();
		str = new StringBuilder();
		str.append("[");
		str.append(Array.getLength(arr));
		str.append("]");
		if(c.getComponentType().isArray()) {
			c=c.getComponentType();
			str.append("[");
			str.append(Array.getLength(arr[0]));
			str.append("]");
		}
		str.append(" = {");
		for (Object object : arr) {
			if(object!=null) {
				if(object.getClass().isArray()) {
					str.append("{");
					for (Object sub : (Object []) object) {
						str.append(sub+", ");
					}
					str.setCharAt(str.length()-2, '}');	
					str.setCharAt(str.length()-1, ',');
					str.append(" ");
					continue;
				}
				
			}
			str.append(object+", ");
		}
		str.setCharAt(str.length()-2, '}');			
		return c.getComponentType().getName()+str.toString();
	}
}

class IllegalDimensionCountException extends IllegalArgumentException{
	private static final long serialVersionUID = 1L;

	@Override
	public void printStackTrace() {
		System.err.println("IllegalDimensionCountException!");
	}
}
