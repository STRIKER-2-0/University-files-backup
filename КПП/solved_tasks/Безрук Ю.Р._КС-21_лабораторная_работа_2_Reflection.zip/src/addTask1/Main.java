package addTask1;

import java.lang.reflect.InvocationTargetException;


public class Main {
	public static void main(String[] args) {
		ObjectCreator c = new ObjectCreator();
		try {
			while(true)
				System.out.println(c.invokeMethod(c.createObject(Test.class)));
		} catch (InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e1) {
			e1.printStackTrace();
		}		
	}

}
class Test {
	IntPair pair;
	String informative;
	DoubleSet set; 
	float num;
	
	public Test() {
		pair = new IntPair();
		informative = "blank";
		set = new DoubleSet();
		num = 0.0f;
	}

	public Test(IntPair pair, String informative, DoubleSet set, float num) {
		this.pair = pair;
		this.informative = informative;
		this.set = set;
		this.num = num;
	}
	public Test(IntPair pair, String informative) {
		this.pair = pair;
		this.informative = informative;
		set = new DoubleSet();
		num = 0.0f;
	}
	public Test(IntPair pair, DoubleSet set) {
		this.pair = pair;
		informative = "blank";
		this.set = set;
		num = 0.0f;
	}
	public Test(IntPair pair, float num) {
		this.pair = pair;
		informative = "blank";
		set = new DoubleSet();
		this.num = num;
	}
	public Test(String informative, DoubleSet set) {
		pair = new IntPair();
		this.informative = informative;
		this.set = set;
		num = 0.0f;
	}
	public Test(String informative, float num) {
		pair = new IntPair();
		this.informative = informative;
		set = new DoubleSet();
		this.num = num;
	}
	public Test(DoubleSet set, float num) {
		pair = new IntPair();
		informative = "blank";
		this.set = set;
		this.num = num;
	}
	public Test(IntPair pair, String informative, DoubleSet set) {
		this.pair = pair;
		this.informative = informative;
		this.set = set;
		num = 0.0f;
	}
	public Test(IntPair pair, DoubleSet set, float num) {
		this.pair = pair;
		informative = "blank";
		this.set = set;
		this.num = num;
	}
	public Test(String informative, DoubleSet set, float num) {
		pair = new IntPair();
		this.informative = informative;
		this.set = set;
		this.num = num;
	}	
	public Test(IntPair pair) {
		this.pair = pair;
		informative = "blank";
		set = new DoubleSet();
		num = 0.0f;
	}
	public Test(String informative) {
		pair = new IntPair();
		this.informative = informative;
		set = new DoubleSet();
		num = 0.0f;
	}
	public Test(DoubleSet set) {
		pair = new IntPair();
		informative = "blank";
		this.set = set;
		num = 0.0f;
	}
	public Test(float num) {
		pair = new IntPair();
		informative = "blank";
		set = new DoubleSet();
		this.num = num;
	}

	public String getPair() {		
		return pair.toString();
	}

	public void setPair(IntPair pair) {
		this.pair = pair;
	}

	public String getInformative() {
		return informative;
	}

	public void setInformative(String informative) {
		this.informative = informative;
	}

	public String getSet() {
		return set.toString();
	}

	public void setSet(DoubleSet set) {
		this.set = set;
	}

	public String getNum() {
		return Float.toString(num);
	}

	public void setNum(float num) {
		this.num = num;
	}
	public String toString() {
		return pair.toString()+"\n"+informative+"\n"+set.toString()+num;
	}
	
}
class IntPair{
	int first;
	int second;
	
	public IntPair(int first, int second) {
		this.first = first;
		this.second = second;
	}
	public IntPair(int first) {
		this.first = first;
		this.second = 0;
	}
	public IntPair() {
		first = 0;
		second = 0;
	}	
	@Override
	public String toString() {
		return first+", " + second;
	}
}
class DoubleSet {
	double one;
	Double two;
	double three;
	
	public DoubleSet(double one, Double two, double three) {
		this.one = one;
		this.two = two;
		this.three = three;
	}
	
	public DoubleSet(double one, double three) {
		this.one = one;
		two = new Double(0);
		this.three = three;
	}
	
	public DoubleSet(double one, Double two) {
		this.one = one;
		this.two = two;
		this.three = 0;
	}
	
	public DoubleSet(Double two, double three) {
		this.one = 0;
		this.two = two;
		this.three = three;
	}
	
	public DoubleSet() {
		this.one = 0;
		this.two = new Double(0);
		this.three = 0;
	}
	@Override
	public String toString() {
		return one+", "+two+", "+three;
	}
	
}