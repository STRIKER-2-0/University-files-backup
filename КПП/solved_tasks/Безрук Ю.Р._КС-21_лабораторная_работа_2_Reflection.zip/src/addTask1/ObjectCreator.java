package addTask1;

import java.lang.reflect.*;
import java.util.Scanner;

public class ObjectCreator {
	
	public Object invokeMethod(Object obj) throws InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {		
		System.out.println("Methods available in class: ");
		Class<?> c = obj.getClass();
		StringBuilder str = new StringBuilder(); 
		Method[] methods = c.getMethods();
		Parameter[] prms;
		int i = 1;
		for (Method method : methods) {
			System.out.print(i+"). "+method.getReturnType().getSimpleName()+" "+method.getName()+" (");
			for (Parameter p : method.getParameters()) {
				str.append(p.getType().getSimpleName()+", ");
			}
			int end = str.length()-2 >= 0 ? str.length()-2 : 0; 
			System.out.println(str.substring(0, end)+");");
			str.setLength(0);
			i++;
		}
		System.out.println("Choose the method to invoke: ");
		Scanner s = new Scanner(System.in);
		i = s.nextInt()-1;
		
		Object args[] = null;
		Object result;
		prms = methods[i].getParameters();
		if(prms.length > 0) {
			args = new Object[prms.length];
			System.out.println("Parameters of method:");
			for (int j = 0; j < args.length; j++) {
				args[j] = createObject(prms[j].getType());
			}
		}
		System.out.println("Method"+ methods[i].getName() + " invoking...");
		result = methods[i].invoke(obj, args);
		getState(obj);
		return result;
	}
	public Object createObject(Class<?> c) throws InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {		
		System.out.println("The beginning of creation the "+ c.getSimpleName() + " object");		
		if(c.isPrimitive() || c == String.class) {
			return createPrimitive(c);
		}
		StringBuilder str = new StringBuilder(); 
		Scanner s = new Scanner(System.in);
		Constructor<?>[] ctrs = c.getConstructors();
		Parameter[] prms;
		
		int i = 1;
		for (Constructor<?> ctr : ctrs) {
			System.out.print(i+"). "+ctr.getDeclaringClass().getSimpleName()+" (");
			prms = ctr.getParameters();
			for (Parameter p : prms) {
				str.append(p.getType().getSimpleName()+", ");
			}
			int end = str.length()-2 >= 0 ? str.length()-2 : 0; 
			System.out.println(str.substring(0, end)+");");
			str.setLength(0);
			i++;
		}
		System.out.print("Enter a number of constructor: ");
		i=s.nextInt()-1;
		
		Object args[] = null;
		Object result;
		prms = ctrs[i].getParameters();
		if(prms.length > 0) {
			args = new Object[prms.length];
			System.out.println("Parameters of constructor:");
			for (int j = 0; j < args.length; j++) {
				args[j] = createObject(prms[j].getType());
			}
		}
		System.out.println("The end of creation the "+ c.getSimpleName() + " object");
		result = ctrs[i].newInstance(args);
		getState(result);
		//s.close();
		return result;		
	}	
	@SuppressWarnings("resource")
	private Object createPrimitive(Class<?> c) {
		System.out.print("Enter the "+c.getSimpleName()+" value: ");		
		if(c == int.class) 			
			return new Scanner(System.in).nextInt();		
		if(c == short.class) 
			return new Scanner(System.in).nextShort();
		if(c == long.class) 
			return new Scanner(System.in).nextLong();
		if(c == byte.class) 
			return new Scanner(System.in).nextByte();
		if(c == char.class) 
			return new Scanner(System.in).next().charAt(0);
		if(c == float.class) 
			return new Scanner(System.in).nextFloat();
		if(c == double.class) 
			return new Scanner(System.in).nextDouble();
		if(c == boolean.class) 
			return new Scanner(System.in).nextBoolean();
		if(c == String.class) 
			return new Scanner(System.in).next();
		return null;
	}
	private void getState(Object obj) {
		Object fieldObject;
		Class<?> c = obj.getClass();
		for(Field f : c.getDeclaredFields()) {
			System.out.print("\t"+f.getType().getSimpleName()+" "+f.getName()+" = ");
			try {
				if(f.getType() == Class.class) {
					System.out.println("~REFLEX~");
					continue;
				}
				if(!f.isAccessible())
					f.setAccessible(true);
				fieldObject = f.get(obj);
				if(fieldObject == null) {
					System.out.print("null");
				}
				else if(fieldObject.getClass() == Integer.class ||
					fieldObject.getClass() == Short.class ||
					fieldObject.getClass() == Long.class ||
					fieldObject.getClass() == Byte.class ||
					fieldObject.getClass() == Character.class ||
					fieldObject.getClass() == Double.class ||
					fieldObject.getClass() == Float.class ||
					fieldObject.getClass() == Boolean.class ||
					fieldObject.getClass() == String.class) {
					System.out.print(fieldObject);
				}
				else {
					System.out.println("{");
					getState(fieldObject);
					System.out.print("\t}");
				}
			} catch (IllegalArgumentException | IllegalAccessException e) {
				e.printStackTrace();
			}
			System.out.println(";");
		}		
	}
}



