package task2;

public class NotNecessaryMethodException extends Exception {
	private static final long serialVersionUID = 1L;

	@Override
	public void printStackTrace() {
		System.err.println("\n!Check the method without arguments!");
	}
}
