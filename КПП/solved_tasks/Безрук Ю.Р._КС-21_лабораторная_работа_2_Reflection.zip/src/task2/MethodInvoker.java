package task2;

import java.lang.reflect.*;

public class MethodInvoker {
	private static StringBuilder str;
	
	public static String getState(Object obj) {
		str = new StringBuilder("��������� �������:\n");
		Class<?> c = obj.getClass();
		for(Field f : c.getDeclaredFields()) {
			addModifiers(f.getModifiers());
			str.append(f.getType().getSimpleName()+" = ");
			try {
				if(!f.isAccessible())
					f.setAccessible(true);
				str.append(f.get(obj));
			} catch (IllegalArgumentException | IllegalAccessException e) {
				e.printStackTrace();
			}
			str.append(";\n");
		}		
		return str.toString();
	}
	public static String getMethods(Object obj) {
		str = new StringBuilder("�������� ������:\n");
		Class<?> c = obj.getClass();
		int i=1;
		for (Method m : c.getDeclaredMethods()) {
			str.append(i+") ");
			addModifiers(m.getModifiers());
			str.append(m.getReturnType()+" ");
			str.append(m.getName()+" (");
			if(m.getParameters().length==0)		
				str.append(");");
			else {				
				for (Parameter p : m.getParameters()) 
					str.append(p.getType().getSimpleName()+" "+p.getName()+", ");				
				str.setCharAt(str.length()-2, ')');
				str.setCharAt(str.length()-1, ';');
			}
			str.append("\n");
			i++;
		}		
		return str.toString();
	}
	public static void invokeMethod(Object obj, int num) throws NotNecessaryMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		num--;
		Class<?> c = obj.getClass();
		Method methods[] = c.getDeclaredMethods();
		if(methods[num].getParameters().length!=0)
			throw new NotNecessaryMethodException();
		methods[num].invoke(obj);		
	}
	public static void invokeMethod(Object obj, String methodName, ParamData... params) throws FunctionNotFoundException {
		Class<?> c = obj.getClass();
		Class<?>[] parameterTypes = new Class<?>[params.length];
		Object[] args = new Object[params.length];
		for (int i = 0; i < params.length; i++) {
			parameterTypes[i]=params[i].type;
			args[i]=params[i].value;
		}
		Method m;
		try {
			m = c.getMethod(methodName, parameterTypes);
			if(!m.isAccessible())
				m.setAccessible(true);
			m.invoke(obj, args);
		} catch (NoSuchMethodException | SecurityException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
			throw new FunctionNotFoundException();
		}
		
	}
	private static void addModifiers(int mod) {
		if (Modifier.isPublic(mod)) str.append("public ");
        if (Modifier.isProtected(mod)) str.append("protected ");
        if (Modifier.isPrivate(mod)) str.append( "private ");
        if (Modifier.isStatic(mod)) str.append("static ");
        if (Modifier.isAbstract(mod)) str.append("abstract ");
        if (Modifier.isFinal(mod)) str.append("final ");
        if (Modifier.isNative(mod)) str.append("native ");
        if (Modifier.isStrict(mod)) str.append("strict ");
        if (Modifier.isSynchronized(mod)) str.append("synchronized");
        if (Modifier.isTransient(mod)) str.append("transiend ");
        if (Modifier.isVolatile(mod)) str.append("volatile ");       
	}
}

