package task2;

import java.lang.reflect.InvocationTargetException;

public class Main{
	public static void main(String[] args) {
		java.util.Scanner s = new java.util.Scanner(System.in);				
		A a = new A();
		a.d=5.8;
		System.out.println(MethodInvoker.getState(a));
		while(true) {
			System.out.println(MethodInvoker.getMethods(a));
			System.out.print("�������� ����� ��� ���������� ���� ������ ��� ������� (0 ��� ������): ");
			int num = s.nextInt();
			if(num==0)
				break;
				try {
					MethodInvoker.invokeMethod(a, num);
				} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException
						| NotNecessaryMethodException e) {
					e.printStackTrace();
				}
			
		}
		s.close();
	}
}

class A{
	private int i;
	private String s;
	double d;
	B a;
	
	A(){
		i=7;
		s="tttt";
		d=34.5;
		a=new B();
	}
	public void method(int a, double b) {
		System.out.println(a+b);
	}
	public void printI() {
		System.out.println(i);
	}
	public void printS() {
		System.out.println(s);
	}
	public void printD() {
		System.out.println(d);
	}
	public void printA() {
		System.out.println(a);
	}
}
class B{
	
}