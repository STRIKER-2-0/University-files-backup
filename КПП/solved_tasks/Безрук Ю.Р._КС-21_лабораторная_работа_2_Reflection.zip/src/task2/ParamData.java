package task2;

public class ParamData{
	public Class<?> type;
	public Object value;
	
	public ParamData(Class<?> c, Object obj){
		type=c;
		value=obj;
	}
}