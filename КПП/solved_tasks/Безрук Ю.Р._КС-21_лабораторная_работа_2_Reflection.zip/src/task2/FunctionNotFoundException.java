package task2;

public class FunctionNotFoundException extends NoSuchMethodException {
	private static final long serialVersionUID = 1L;

	@Override
	public void printStackTrace() {
		System.err.println("Cannot invoke the method!");
	}
}
