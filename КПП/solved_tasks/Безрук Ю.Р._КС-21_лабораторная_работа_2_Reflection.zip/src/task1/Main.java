package task1;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Main {
	public static void main(String[] args) throws ClassNotFoundException {
		AnalyzatorFrame frame = new AnalyzatorFrame();
		frame.setVisible(true);
		
		/*
		System.out.print("Enter class name: ");
		java.util.Scanner s = new java.util.Scanner(System.in);
		try {
			String analyzisRequest = s.next();
			System.out.println(Analyzator.analyze(analyzisRequest));
		} catch (ClassNotFoundException e) {
			System.out.println("Class not found!");
			s.close();
		}*/
	}

	
}
class AnalyzatorFrame extends JFrame {
	private static final long serialVersionUID = 1L;
	JPanel main;
	JPanel enter;
	JLabel enterLabel;
	JTextField enterTextField;
	JTextArea out;
	JPanel buttons;
	JButton analyze;
	JButton clear;
	JScrollPane scroll;

	AnalyzatorFrame() {
		setTitle("Class analizator");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(500, 500);
		setResizable(false);
		main = new JPanel(new BorderLayout());

		enter = new JPanel(new GridLayout());
		enterLabel = new JLabel("    Enter class name: ");
		enterTextField = new JTextField();
		enterTextField.addKeyListener(new KeyListener() {
			@Override
			public void keyReleased(KeyEvent e) {
				if (e.getKeyCode() == KeyEvent.VK_ENTER) {
					try {
						out.setText(Analyzator.analyze(enterTextField.getText()));
					} catch (Exception e2) {
						out.setText("Class not Found!");
					}
				}
			}

			public void keyTyped(KeyEvent e) {
			}

			public void keyPressed(KeyEvent e) {
			}
		});
		enter.add(enterLabel);
		enter.add(enterTextField);
		main.add(enter, BorderLayout.NORTH);

		out = new JTextArea();
		scroll = new JScrollPane(out);
		scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		main.add(scroll, BorderLayout.CENTER);

		buttons = new JPanel(new FlowLayout());
		analyze = new JButton("Analyze");
		analyze.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					out.setText(Analyzator.analyze(enterTextField.getText()));
				} catch (Exception e2) {
					out.setText("Class not Found!");
				}
			}
		});
		buttons.add(analyze);
		clear = new JButton("Clear");
		clear.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				out.setText("");
			}
		});
		buttons.add(clear);
		main.add(buttons, BorderLayout.SOUTH);
		main.setFocusable(true);
		add(main);
	}
}
