package task1;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.Parameter;

public class Analyzator {
	private static StringBuilder str;
	
	public static String analyze(Class<?> c) {
		str = new StringBuilder();
		if(c.isPrimitive()) 
			analyzePrimitive(c);
		else if(c.isArray()) 
			analyzeArray(c);
		else 
			analyzeClass(c);
		return str.toString();
	}
	public static String analyze(String className) throws ClassNotFoundException {
		return analyze(Class.forName(className));
	} 
	
	private static void analyzePrimitive(Class<?> c) {
		str.append("primitive "+c.getName());
	}
	private static void analyzeArray(Class<?> c) {
		addModifiers(c.getModifiers());	
		str.append("array "+c.getSimpleName()+"\n");		
		while (c.getComponentType().isArray());	
	}
	private static void analyzeClass(Class<?> c) {
		str.append((c.getPackage()+"\n\n"));		//package
		addModifiers(c.getModifiers());				//modifiers
		
		if (c.isInterface()) str.append("interface ");		//type
        else str.append("class ");
		
		str.append(c.getSimpleName());				//name
		str.append(" extends ");				//extends+superclass if class or extends if Interface
		if (!c.isInterface()) str.append(c.getSuperclass().getSimpleName());
		
		if(c.getInterfaces().length>0) {	//if have interfaces
			if (!c.isInterface()) str.append(" implements ");	//implements if class
			for (Class<?> i : c.getInterfaces()) 
				str.append(i.getSimpleName()+", ");			//just appending to extends if Interface
			str.setCharAt(str.length()-2, ' ');			//delete last comma
		}
		str.append("{\n\n");
		addFields(c);				
		addConstructors(c);			
		addMethods(c);			
		str.append("}");
	}
	private static void addModifiers(int mod) {
		if (Modifier.isPublic(mod)) str.append("public ");
        if (Modifier.isProtected(mod)) str.append("protected ");
        if (Modifier.isPrivate(mod)) str.append( "private ");
        if (Modifier.isStatic(mod)) str.append("static ");
        if (Modifier.isAbstract(mod)) str.append("abstract ");
        if (Modifier.isFinal(mod)) str.append("final ");
        if (Modifier.isNative(mod)) str.append("native ");
        if (Modifier.isStrict(mod)) str.append("strict ");
        if (Modifier.isSynchronized(mod)) str.append("synchronized");
        if (Modifier.isTransient(mod)) str.append("transiend ");
        if (Modifier.isVolatile(mod)) str.append("volatile ");       
	}
	private static void addFields(Class<?> c) {
		Field[] fs = c.getFields();		//extending fields and public declared
		for (Field f : fs) {
			str.append("\t");
			addModifiers(f.getModifiers());
			if(!f.getType().isInterface())
				str.append(f.getType().getSimpleName());
			else
				str.append(f.getType());
			str.append(" "+f.getName());
			str.append(";\n");
		}
		
		for (Field f : c.getDeclaredFields()) {		//all declared fields
			boolean availableField = false;
			for (int i = 0; i < fs.length; i++) 	//checking if this field available in buffer(if it is public)
				if(f.equals(fs[i])) availableField = true;
			if(availableField) continue;
			
			str.append("\t");
			addModifiers(f.getModifiers());
			if(!f.getType().isInterface())
				str.append(f.getType().getSimpleName());
			else
				str.append(f.getType());
			str.append(" "+f.getName());
			str.append(";\n");			
		}		
	}
	private static void addConstructors(Class<?> c) {
		Constructor<?> ctrs[] = c.getConstructors();
		for (Constructor<?> ctr : ctrs) {
			str.append("\n\t");
			addModifiers(ctr.getModifiers());		//ctr modifiers
			str.append(ctr.getDeclaringClass().getSimpleName()+" (");	//ctr name
			
			if(ctr.getParameters().length==0)		//if have no params
				str.append(");");
			else {				//if have params
				for (Parameter p : ctr.getParameters()) 
					str.append(p.getType().getSimpleName()+" "+p.getName()+", ");				
				str.setCharAt(str.length()-2, ')');
				str.setCharAt(str.length()-1, ';');
			}
		}
		
		for (Constructor<?> ctr : c.getDeclaredConstructors()) {		//all declared ctrs
			boolean availableConstructor = false;
			for (int i = 0; i < ctrs.length; i++) 	//checking if this ctr available in buffer(if it is public)
				if(ctr.equals(ctrs[i])) availableConstructor = true;
			if(availableConstructor) continue;
			
			str.append("\n\t");
			addModifiers(ctr.getModifiers());
			str.append(ctr.getDeclaringClass().getSimpleName()+" (");	//ctr's name
			
			if(ctr.getParameters().length==0)
				str.append(");");
			else {
				for (Parameter p : ctr.getParameters()) 
					str.append(p.getType().getSimpleName()+" "+p.getName()+", ");				
				str.setCharAt(str.length()-2, ')');
				str.setCharAt(str.length()-1, ';');
			}			
		}
		str.append("\n");
	}
	private static void addMethods(Class<?> c) {
		Method[] ms = c.getMethods();		//extending and public declaed methods
		for (Method m : ms) {
			str.append("\n\t");
			addModifiers(m.getModifiers());		//method modifiers
			str.append(m.getReturnType().getSimpleName()+" ");		//method type
			str.append(m.getName()+" (");	//method name
			
			if(m.getParameters().length==0)		//if have no params
				str.append(");");
			else {				//if have params
				for (Parameter p : m.getParameters()) 
					str.append(p.getType().getSimpleName()+" "+p.getName()+", ");				
				str.setCharAt(str.length()-2, ')');
				str.setCharAt(str.length()-1, ';');
			}			
		}
		
		for (Method m : c.getDeclaredMethods()) {		//all declared methods
			boolean availableMethod = false;
			for (int i = 0; i < ms.length; i++) 	//checking if this method available in buffer(if it is public)
				if(m.equals(ms[i])) availableMethod = true;
			if(availableMethod) continue;
			
			str.append("\n\t");
			addModifiers(m.getModifiers());
			str.append(m.getReturnType().getSimpleName()+" ");
			str.append(m.getName()+" (");
			if(m.getParameters().length==0)
				str.append(");");
			else {
				for (Parameter p : m.getParameters()) 
					str.append(p.getType().getSimpleName()+" "+p.getName()+", ");				
				str.setCharAt(str.length()-2, ')');
				str.setCharAt(str.length()-1, ';');
			}			
		}
		str.append("\n");
	}	
}
