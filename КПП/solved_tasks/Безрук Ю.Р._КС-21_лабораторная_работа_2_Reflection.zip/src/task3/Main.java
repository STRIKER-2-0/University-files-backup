package task3;

import task2.MethodInvoker;
import task2.ParamData;

public class Main{
	public static void main(String[] args) {
		java.util.Scanner s = new java.util.Scanner(System.in);
		ParamData[] params = new ParamData[2];
		params[0] = new ParamData(String.class, "hahaha");
		params[1] = new ParamData(Class.class, java.util.Scanner.class);
		A a = new A();
		try {			
			MethodInvoker.invokeMethod(a, "str", params);
		} catch (SecurityException | NoSuchMethodException | IllegalArgumentException e) {
			e.printStackTrace();
		}
		
		s.close();
	}
}

class A{
	private int i;
	private String s;
	double d;
	B a;
	
	A(){
		i=7;
		s="tttt";
		d=34.5;
		a=new B();
	}
	public void method(int a, double b) {
		System.out.println(a+b);
	}
	public void str(String str, Class<?> c) {
		System.out.println(str+c.getSimpleName());
	}
	public void printI() {
		System.out.println(i);
	}
	public void printS() {
		System.out.println(s);
	}
	public void printD() {
		System.out.println(d);
	}
	public void printA() {
		System.out.println(a);
	}
}
class B{
	
}