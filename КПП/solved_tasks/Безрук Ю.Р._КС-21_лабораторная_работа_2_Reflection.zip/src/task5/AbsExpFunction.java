package task5;

public class AbsExpFunction extends FFunction implements Evaluatable{	
	public AbsExpFunction() {
		super();
	}
	public AbsExpFunction(double a) {
		super(a);
	}
	
	@Override
	public double evalf(double x) {
		return Math.exp(-Math.abs(a)*x)*Math.sin(x);
	}
}
