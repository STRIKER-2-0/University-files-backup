package task5;

public interface Evaluatable {
	double evalf(double x);
}
