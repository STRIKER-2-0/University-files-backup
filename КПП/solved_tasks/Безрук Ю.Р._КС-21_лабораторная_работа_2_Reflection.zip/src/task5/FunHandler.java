package task5;
import java.lang.reflect.*;

public class FunHandler implements InvocationHandler {
	private Object obj = null;
		
	public FunHandler(Object obj) {
		super();
		this.obj = obj;
	}
	
	@Override
	public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
		long nanos = System.nanoTime();
        Object result = method.invoke(obj, args);
        long current_nanos = System.nanoTime()-nanos;
        
        StringBuilder str = new StringBuilder();
        str.append(String.format("������ ������: %s(", method.getName()));
        
        int i = 0;
        for (Parameter p : method.getParameters()) {
        	str.append(String.format("%s %s = %.1f, ", p.getType().getSimpleName(), p.getName(), args[i]));
			i++;
		}
        str.setCharAt(str.length()-2, ')');
        str.append(String.format("= %.10f%n���������� ������ %d ����������\n", result, current_nanos));
        System.out.println(str.toString());
        return result;
	}	
}
