package task5;

public class SqureFunction implements Evaluatable {

	@Override
	public double evalf(double x) {
		return x*x;
	}

}
