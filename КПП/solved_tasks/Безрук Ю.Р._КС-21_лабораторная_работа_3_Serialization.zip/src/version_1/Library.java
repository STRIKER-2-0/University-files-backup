package version_1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Library implements Serializable {
	private static final long serialVersionUID = 1469519286561818321L;
	private String name;
	private List<BookStore> stores;
	private List<BookReader> readers;
	
	public Library() {
		name = "Some_library";
		stores = new ArrayList<BookStore>();
		stores.add(new BookStore());
		readers = new ArrayList<BookReader>();
		readers.add(new BookReader());
	}

	public Library(String name, List<BookStore> stores, List<BookReader> readers) {
		this.stores = stores;
		this.readers = readers;
	}
	public Library(String name, BookStore[] stores, BookReader[] readers) {
		this.stores = new ArrayList<BookStore>();
		for (BookStore store : stores) {
			this.stores.add(store);
		}
		this.readers = new ArrayList<BookReader>();
		for (BookReader bookReader : readers) {
			this.readers.add(bookReader);
		}
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public List<BookStore> getStores() {
		return stores;
	}

	public void setStores(List<BookStore> stores) {
		this.stores = stores;
	}
	
	public void setStores(BookStore[] stores) {
		this.stores = new ArrayList<BookStore>();
		for (BookStore store : stores) {
			this.stores.add(store);
		}
	}
	
	public void addStore(BookStore store) {
		this.stores.add(store);
	}
	
	public BookStore getBookStore(int index) {
		return stores.get(index);
	}
	
	public BookStore getBookStore(String name) {
		for (BookStore store : stores) {
			if(store.getName().equals(name))
				return store;
		}
		return null;
	}
	
	public void removeBookStore(int index) {
		stores.remove(index);
	}
	
	public void removeBookStore(String name) {
		for (BookStore store : stores) {
			if(store.getName().equals(name)) {
				stores.remove(store);
				break;
			}
		}
	}
	
	public List<BookReader> getReaders() {
		return readers;
	}

	public void setReaders(List<BookReader> readers) {
		this.readers = readers;
	}
	
	public void setReaders(BookReader[] readers) {
		this.readers = new ArrayList<BookReader>();
		for (BookReader bookReader : readers) {
			this.readers.add(bookReader);
		}
	}
	public void addReader(BookReader reader) {
		this.readers.add(reader);
	}
	
	public BookReader getReader(int index) {
		return readers.get(index);
	}
	
	public BookReader getReader(String name) {
		for (BookReader reader : readers) {
			if(reader.getName().equals(name))
				return reader;
		}
		return null;
	}
	
	public void removeReader(int index) {
		readers.remove(index);
	}
	
	public void removeReader(String name) {
		for (BookReader reader : readers) {
			if(reader.getName().equals(name)) {
				readers.remove(reader);
				break;
			}
		}
	}
	
	@Override
	public String toString() {
		StringBuilder str = new StringBuilder("library "+name+":\nbookstores: [ ");
		for (BookStore store : stores) {
			str.append("{"+store.toString()+"}, ");
		}
		str.setCharAt(str.length()-2, ' ');
		str.setCharAt(str.length()-1, ']');
		str.append("\nbook readers: [ ");
		for (BookReader bookReader : readers) {
			str.append("{"+bookReader.toString()+"}, ");
		}
		str.setCharAt(str.length()-2, ' ');
		str.setCharAt(str.length()-1, ']');
		return str.toString();
	}
}
