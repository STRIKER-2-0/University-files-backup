package version_1;

public class Author extends Human {
	private static final long serialVersionUID = -6231185274442608370L;
	
	public Author() {
		name = "Somebody";
		sername = "Some_Sername";
	}
	public Author(String name, String sername) {
		this.name = name;
		this.sername = sername;
	}
	@Override
	public String toString() {
		return super.toString();
	}
}
