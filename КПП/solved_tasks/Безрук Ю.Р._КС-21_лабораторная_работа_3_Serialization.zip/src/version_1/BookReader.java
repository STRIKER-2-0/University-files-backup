package version_1;

import java.util.ArrayList;
import java.util.List;

public class BookReader extends Human {
	private static final long serialVersionUID = -8464501156376125039L;
	private int registrationNumber;
	private List<Book> receivedBooks;

	public BookReader() {
		name = "Somebody";
		sername = "Some_Sername";
		registrationNumber = 1;
		receivedBooks = new ArrayList<Book>();
		receivedBooks.add(new Book());
	}
	public BookReader(String name, String sername, int registrationNumber, List<Book> receivedBooks) {
		this.name = name;
		this.sername = sername;
		this.registrationNumber = registrationNumber;
		this.receivedBooks = receivedBooks;
	}
	public BookReader(String name, String sername, int registrationNumber, Book[] receivedBooks) {
		this.name = name;
		this.sername = sername;
		this.registrationNumber = registrationNumber;
		this.receivedBooks = new ArrayList<Book>(); 
		for (Book book : receivedBooks) {
			this.receivedBooks.add(book);
		}
	}
	public int getRegistrationNumber() {
		return registrationNumber;
	}
	public void setRegistrationNumber(int registrationNumber) {
		this.registrationNumber = registrationNumber;
	}
	public List<Book> getReceivedBooks() {
		return receivedBooks;
	}
	public void setReceivedBooks(List<Book> receivedBooks) {
		this.receivedBooks = receivedBooks;
	}
	public void setReceivedBooks(Book[] receivedBooks) {
		this.receivedBooks = new ArrayList<Book>(); 
		for (Book book : receivedBooks) {
			this.receivedBooks.add(book);
		}
	}
	public void addReceivedBook(Book book) {
		this.receivedBooks.add(book);
	}
	public Book getReceivedBook(int index) {
		return receivedBooks.get(index);
	}
	public Book getReceivedBook(String name) {
		for (Book book : receivedBooks) {
			if(book.getName().equals(name))
				return book;
		}
		return null;
	}
	public void removeReceivedBook(int index) {
		receivedBooks.remove(index);
	}
	
	public void removeReceivedBook(String name) {
		for (Book book : receivedBooks) {
			if(book.getName().equals(name)) {
				receivedBooks.remove(book);
				break;
			}
		}
	}
	@Override
	public String toString() {		
		StringBuilder str = new StringBuilder(super.toString());
		str.append(", id: "+registrationNumber+", received books: [ ");
		for (Book book : receivedBooks) {
			str.append("{"+book.toString()+"}, ");
		}
		str.setCharAt(str.length()-2, ' ');
		str.setCharAt(str.length()-1, ']');
		return str.toString();
	}
}
