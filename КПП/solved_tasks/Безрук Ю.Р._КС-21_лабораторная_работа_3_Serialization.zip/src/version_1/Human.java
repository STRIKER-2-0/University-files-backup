package version_1;

import java.io.Serializable;

public abstract class Human implements Serializable {
	private static final long serialVersionUID = -1432192043760781233L;
	protected String name;
	protected String sername;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSername() {
		return sername;
	}
	public void setSername(String sername) {
		this.sername = sername;
	}
	@Override
	public String toString() {
		return name + " " + sername;
	}
}
