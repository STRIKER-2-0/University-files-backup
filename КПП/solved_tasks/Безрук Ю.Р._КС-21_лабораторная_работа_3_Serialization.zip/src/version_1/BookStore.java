package version_1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class BookStore implements Serializable {
	private static final long serialVersionUID = 2630965171045560605L;
	private String name;
	private List<Book> store;
	
	public BookStore() {
		name = "Some_bookstore";
		store = new ArrayList<Book>();
		store.add(new Book());
	}

	public BookStore(String name, List<Book> store) {
		this.name = name;
		this.store = store;
	}
	
	public BookStore(String name, Book[] store) {
		this.name = name;
		this.store = new ArrayList<Book>();
		for (Book book : store) {
			this.store.add(book);
		}
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Book> getStore() {
		return store;
	}

	public void setStore(List<Book> store) {
		this.store = store;
	}
	
	public void setStore(Book[] store) {
		this.store = new ArrayList<Book>();
		for (Book book : store) {
			this.store.add(book);
		}
	}
	
	public void addBook(Book book) {
		store.add(book);
	}
	
	public Book getBook(int index) {
		return store.get(index);
	}
	
	public Book getBook(String name) {
		for (Book book : store) {
			if(book.getName().equals(name));
				return book;
		}
		return null;
	}
	
	public void removeBook(int index) {
		store.remove(index);
	}
	
	public void removeBook(String name) {
		for (Book book : store) {
			if(book.getName().equals(name)) {
				store.remove(book);
				break;
			}
		}
	}
	
	@Override
	public String toString() {
		StringBuilder str = new StringBuilder("bookstore "+name+": [ ");
		for (Book book : store) {
			str.append("{"+book.toString()+"}, ");
		}
		str.setCharAt(str.length()-2, ' ');
		str.setCharAt(str.length()-1, ']');
		return str.toString();
	}
}
