package version_2;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Library implements Serializable {
	private static final long serialVersionUID = 1469519286561818321L;
	private String name;
	private List<BookStore> stores;
	private transient List<BookReader> readers;
	
	public Library() {
		name = "Some_library";
		stores = new ArrayList<BookStore>();
		stores.add(new BookStore());
		readers = new ArrayList<BookReader>();
		readers.add(new BookReader());
	}

	public Library(String name, List<BookStore> stores, List<BookReader> readers) {
		this.stores = stores;
		this.readers = readers;
	}
	public Library(String name, BookStore[] stores, BookReader[] readers) {
		this.stores = new ArrayList<BookStore>();
		for (BookStore store : stores) {
			this.stores.add(store);
		}
		this.readers = new ArrayList<BookReader>();
		for (BookReader bookReader : readers) {
			this.readers.add(bookReader);
		}
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public List<BookStore> getStores() {
		return stores;
	}

	public void setStores(List<BookStore> stores) {
		this.stores = stores;
	}
	
	public void setStores(BookStore[] stores) {
		this.stores = new ArrayList<BookStore>();
		for (BookStore store : stores) {
			this.stores.add(store);
		}
	}
	
	public void addStore(BookStore store) {
		this.stores.add(store);
	}
	
	public BookStore getBookStore(int index) {
		return stores.get(index);
	}
	
	public BookStore getBookStore(String name) {
		for (BookStore store : stores) {
			if(store.getName().equals(name))
				return store;
		}
		return null;
	}
	
	public void removeBookStore(int index) {
		stores.remove(index);
	}
	
	public void removeBookStore(String name) {
		for (BookStore store : stores) {
			if(store.getName().equals(name)) {
				stores.remove(store);
				break;
			}
		}
	}
	
	public List<BookReader> getReaders() {
		return readers;
	}

	public void setReaders(List<BookReader> readers) {
		this.readers = readers;
	}
	
	public void setReaders(BookReader[] readers) {
		this.readers = new ArrayList<BookReader>();
		for (BookReader bookReader : readers) {
			this.readers.add(bookReader);
		}
	}
	public void addReader(BookReader reader) {
		this.readers.add(reader);
	}
	
	public BookReader getReader(int index) {
		return readers.get(index);
	}
	
	public BookReader getReader(String name) {
		for (BookReader reader : readers) {
			if(reader.getName().equals(name))
				return reader;
		}
		return null;
	}
	
	public void removeReader(int index) {
		readers.remove(index);
	}
	
	public void removeReader(String name) {
		for (BookReader reader : readers) {
			if(reader.getName().equals(name)) {
				readers.remove(reader);
				break;
			}
		}
	}
	
	@Override
	public String toString() {
		StringBuilder str = new StringBuilder("library "+name+":\nbookstores: [ ");
		for (BookStore store : stores) {
			str.append("{"+store.toString()+"}, ");
		}
		str.setCharAt(str.length()-2, ' ');
		str.setCharAt(str.length()-1, ']');
		str.append("\nbook readers: [ ");
		for (BookReader bookReader : readers) {
			str.append("{"+bookReader.toString()+"}, ");
		}
		str.setCharAt(str.length()-2, ' ');
		str.setCharAt(str.length()-1, ']');
		return str.toString();
	}
	
	private void writeObject(ObjectOutputStream out) throws IOException {
		out.defaultWriteObject();
		out.writeInt(readers.size());
		for (BookReader r : readers) {
			out.writeObject(r.getName());
			out.writeObject(r.getSername());
			out.writeInt(r.getRegistrationNumber());
			out.writeInt(r.getReceivedBooks().size());
			for (Book book : r.getReceivedBooks()) {
				out.writeObject(book.getName());
				out.writeInt(book.getAuthors().size());
				for (Author a : book.getAuthors()) {
					out.writeObject(a.getName());
					out.writeObject(a.getSername());
				}
				out.writeInt(book.getYear());
				out.writeInt(book.getPublicationNumber());
			}
		}
		
	}
	private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
		in.defaultReadObject();
		readers = new ArrayList<BookReader>();
		
		int readersSize = in.readInt();		
		for (int i = 0; i < readersSize; i++) {
			BookReader r = new BookReader();
			r.setName((String) in.readObject());
			r.setSername((String) in.readObject());
			r.setRegistrationNumber(in.readInt());
			
			List<Book> books = new ArrayList<Book>();
			int booksSize = in.readInt();
			for (int j = 0; j < booksSize; j++) {
				Book book = new Book();
				book.setName((String) in.readObject());
				
				List<Author> authors = new ArrayList<Author>();
				int authorsSize = in.readInt();
				for (int k = 0; k < authorsSize; k++) {
					authors.add(new Author((String)in.readObject(), (String)in.readObject()));
				}
				book.setAuthors(authors);
				book.setYear(in.readInt());
				book.setPublicationNumber(in.readInt());
				books.add(book);
			}
			r.setReceivedBooks(books);
			readers.add(r);
		}
	}
}
