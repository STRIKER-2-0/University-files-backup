package version_2;

public abstract class Human  {
	protected String name;
	protected String sername;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSername() {
		return sername;
	}
	public void setSername(String sername) {
		this.sername = sername;
	}
	@Override
	public String toString() {
		return name + " " + sername;
	}
}
