package version_2;


public class Author extends Human {
	
	public Author() {
		name = "Somebody";
		sername = "Some_Sername";
	}
	public Author(String name, String sername) {
		this.name = name;
		this.sername = sername;
	}
	@Override
	public String toString() {
		return super.toString();
	}
	
}
