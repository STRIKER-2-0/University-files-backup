package version_3;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.util.ArrayList;
import java.util.List;

public class BookStore implements Externalizable {
	private String name;
	private List<Book> store;
	
	public BookStore() {
		name = "Some_bookstore";
		store = new ArrayList<Book>();
		store.add(new Book());
	}

	public BookStore(String name, List<Book> store) {
		this.name = name;
		this.store = store;
	}
	
	public BookStore(String name, Book[] store) {
		this.name = name;
		this.store = new ArrayList<Book>();
		for (Book book : store) {
			this.store.add(book);
		}
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Book> getStore() {
		return store;
	}

	public void setStore(List<Book> store) {
		this.store = store;
	}
	
	public void setStore(Book[] store) {
		this.store = new ArrayList<Book>();
		for (Book book : store) {
			this.store.add(book);
		}
	}
	
	public void addBook(Book book) {
		store.add(book);
	}
	
	public Book getBook(int index) {
		return store.get(index);
	}
	
	public Book getBook(String name) {
		for (Book book : store) {
			if(book.getName().equals(name));
				return book;
		}
		return null;
	}
	
	public void removeBook(int index) {
		store.remove(index);
	}
	
	public void removeBook(String name) {
		for (Book book : store) {
			if(book.getName().equals(name)) {
				store.remove(book);
				break;
			}
		}
	}
	
	@Override
	public String toString() {
		StringBuilder str = new StringBuilder("bookstore "+name+": [ ");
		for (Book book : store) {
			str.append("{"+book.toString()+"}, ");
		}
		str.setCharAt(str.length()-2, ' ');
		str.setCharAt(str.length()-1, ']');
		return str.toString();
	}
	
	@Override
	public void writeExternal(ObjectOutput out) throws IOException {
		out.writeObject(name);
		out.writeInt(store.size());
		for (Book book : store) {
			book.writeExternal(out);
		}
	}
	@Override
	public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
		name = (String) in.readObject();
		store =  new ArrayList<Book>();
		int size = in.readInt();
		for (int i = 0; i < size; i++) {
			Book book = new Book();
			book.readExternal(in);
			store.add(book);
		}
	}
}
