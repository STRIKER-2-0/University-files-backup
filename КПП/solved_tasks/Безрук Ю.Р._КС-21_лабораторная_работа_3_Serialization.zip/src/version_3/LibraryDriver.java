package version_3;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;


public class LibraryDriver {

	public static void serialyzeObject(String filename, Object obj) {
		try {
			ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename));
			oos.writeObject(obj);
			oos.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static Object deserialyzeObject(String filename) {
		Object obj = null;
		try {
			ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filename));
			obj = (Library) ois.readObject();
			ois.close();
		} catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		return obj;
	}
	
	public static void main(String[] args) {
		Library l = new Library();
		l.addStore(new BookStore());
		serialyzeObject("library_version_3.bin", l);
		l = (Library) deserialyzeObject("library_version_3.bin");
		System.out.println(l.toString());
	}
}
