package version_3;


import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.util.ArrayList;
import java.util.List;

public class Book implements Externalizable {
	private String name;
	private List<Author> authors;
	private int year;
	private int PublicationNumber;
	
	public Book() {
		name = "Some_book";
		authors = new ArrayList<Author>();
		authors.add(new Author());
		year = 2000;
		PublicationNumber = 1;
	}

	public Book(String name, List<Author> authors, int year, int publicationNumber) {
		this.name = name;
		this.authors = authors;
		this.year = year;
		PublicationNumber = publicationNumber;
	}
	public Book(String name, Author[] authors, int year, int publicationNumber) {
		this.name = name;
		this.authors = new ArrayList<Author>();
		for (Author author : authors) {
			this.authors.add(author);
		}
		this.year = year;
		PublicationNumber = publicationNumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Author> getAuthors() {
		return authors;
	}

	public void setAuthors(List<Author> authors) {
		this.authors = authors;
	}
	
	public void setAuthors(Author[] authors) {
		this.authors = new ArrayList<Author>();
		for (Author author : authors) {
			this.authors.add(author);
		}
	}
	
	public void addAuthor(Author author) {
		this.authors.add(author);
	}
	
	public Author getAuthor(int index) {
		return authors.get(index);
	}
	
	public Author getAuthor(String sername) {
		for (Author author : authors) {
			if(author.getSername().equals(sername)) 
				return author;
		}
		return null;
	}
	
	public void removeAuthor(int index) {
		authors.remove(index);
	}
	
	public void removeAuthor(String sername) {
		for (Author author : authors) {
			if(author.getSername().equals(sername)) {
				authors.remove(author);
				break;
			}
		}
	}
	
	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public int getPublicationNumber() {
		return PublicationNumber;
	}

	public void setPublicationNumber(int publicationNumber) {
		PublicationNumber = publicationNumber;
	}
	@Override
	public String toString() {
		StringBuilder str = new StringBuilder("\""+name+"\"- ");
		for (Author author : authors) {
			str.append(author+", ");
		}
		str.append(year+", ");
		str.append("vol. "+PublicationNumber);
		return str.toString();
	}
	
	@Override
	public void writeExternal(ObjectOutput out) throws IOException {
		out.writeObject(name);
		out.writeInt(authors.size());
		for (Author author : authors) {
			author.writeExternal(out);
		}
		out.writeInt(year);
		out.writeInt(PublicationNumber);
	}
	@Override
	public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
		name = (String) in.readObject();
		authors = new ArrayList<Author>();
		int size = in.readInt();
		for (int i = 0; i < size; i++) {
			Author author = new Author();
			author.readExternal(in);
			authors.add(author);
		}
		year = in.readInt();
		PublicationNumber = in.readInt();
	}
}
