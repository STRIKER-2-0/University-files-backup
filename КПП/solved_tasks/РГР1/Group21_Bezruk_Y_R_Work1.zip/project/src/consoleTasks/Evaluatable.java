package consoleTasks;

public interface Evaluatable {
	double evalf(double x);
}

