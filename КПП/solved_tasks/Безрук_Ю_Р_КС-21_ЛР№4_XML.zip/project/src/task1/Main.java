package task1;

import java.io.*;

import javax.xml.parsers.*;

import org.xml.sax.SAXException;

public class Main {
	public static void main(String[] args) {
		SAXParserFactory factory = SAXParserFactory.newInstance();
		try {
			SAXParser parser = factory.newSAXParser();
			NotebookHandler handler = new NotebookHandler();
			InputStream xmlStream = new FileInputStream("�������� ��� (���������).xml");
			parser.parse(xmlStream, handler);
		} catch (ParserConfigurationException | SAXException | IOException e) {
			e.printStackTrace();
		}
		
	}
}
