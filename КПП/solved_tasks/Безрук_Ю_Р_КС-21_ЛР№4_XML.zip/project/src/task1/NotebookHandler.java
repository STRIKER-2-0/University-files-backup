package task1;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class NotebookHandler extends DefaultHandler{
	private int nesting=0;	//������� �����������
	
	private String tabbing() {
		String result="";
		for(int i=0; i<=nesting; i++)
			result+="\t";
		return result;
	}
	
	@Override
	public void startDocument() throws SAXException {
		System.out.println("Start document processing...");
		nesting++;
	}
	@Override
	public void endDocument() throws SAXException {
		System.out.println("Stop document processing.");
	}
	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
		System.out.print("\n"+tabbing()+"<"+qName+">");
		for (int i = 0; i < attributes.getLength(); i++) {
			System.out.println(attributes.getQName(i).trim()+": "+attributes.getValue(i).trim());
		}
		nesting++;
	}
	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {
		nesting--;
		System.out.print("\n"+tabbing()+"</"+qName+">");
		
	}
	@Override
	public void characters(char[] ch, int start, int length) throws SAXException {
		String str = new String(ch, start, length);
		if(str.trim().equals(""))
			return;
		System.out.print("\n"+tabbing()+str.trim());
	}
}
