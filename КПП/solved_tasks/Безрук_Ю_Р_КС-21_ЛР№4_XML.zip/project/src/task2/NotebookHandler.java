package task2;

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class NotebookHandler extends DefaultHandler{
	private int nesting = 0;	//������� �����������
	private boolean opened = false;
	
	private DocumentBuilderFactory domFactory;
	private DocumentBuilder db;
	private Document doc;
	private Element root;
	private Element subroot;
	private Element element;
	
	public NotebookHandler() {		
		try {
			domFactory = DocumentBuilderFactory.newInstance();
			db = domFactory.newDocumentBuilder();
			doc = db.newDocument();
			root = doc.createElement("DTPDATA");
			doc.appendChild(root);
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		}	
	}
	public void formXML() {		
		Transformer trf = null;
	    DOMSource src = null;
	    try {
			trf = TransformerFactory.newInstance().newTransformer();
			trf.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
			trf.setOutputProperty(OutputKeys.STANDALONE, "yes");
			trf.setOutputProperty(OutputKeys.INDENT, "yes");
			trf.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
			doc.setXmlStandalone(true);
			src = new DOMSource(doc);
			StreamResult result = new StreamResult(new File("coords.xml"));
		    trf.transform(src, result);
		} catch (TransformerFactoryConfigurationError | TransformerException e) {
			e.printStackTrace();
		}
	    
	}
	private String tabbing() {
		String result="";
		for(int i=0; i<=nesting; i++)
			result+="\t";
		return result;
	}
	
	@Override
	public void startDocument() throws SAXException {	
		subroot = doc.createElement("dtpCardList");
		root.appendChild(subroot);
		System.out.println("Start document processing...");
		nesting++;
	}
	@Override
	public void endDocument() throws SAXException {		
		System.out.println("\nStop document processing.");
		nesting--;
	}
	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
		if(qName.equals("regName") || qName.equals("district") || qName.equals("COORD_L") || qName.equals("COORD_W")) {
			element = doc.createElement(qName);
			subroot.appendChild(element);
			System.out.print("\n"+tabbing()+"<"+qName+">");
			nesting++;
			opened = true;
		}
	}
	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {
		if(qName.equals("regName") || qName.equals("district") || qName.equals("COORD_L") || qName.equals("COORD_W")) {			
			nesting--;
			System.out.print("\n"+tabbing()+"</"+qName+">");
			opened = false;
		}
	}
	@Override
	public void characters(char[] ch, int start, int length) throws SAXException {
		if(opened) {
			String str = new String(ch, start, length);
			if(str.trim().equals(""))
				return;
			System.out.print("\n"+tabbing()+str.trim());
			element.setTextContent(str.trim());
		}
	}
}
