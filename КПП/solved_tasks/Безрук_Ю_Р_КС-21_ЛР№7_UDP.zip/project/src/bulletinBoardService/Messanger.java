package bulletinBoardService;

public interface Messanger {
	void start();
	void stop();
	void send();
}
