package bulletinBoardService;

public interface UITasks {
	String getMessage();
	void setText(String txt);

}
