void init();
void TimerInit();
void GPIOinit();
void INTTIM_Config();
void adc_leds_init();
void adc_init();
