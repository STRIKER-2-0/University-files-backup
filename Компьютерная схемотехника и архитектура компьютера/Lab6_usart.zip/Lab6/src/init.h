void init();
void gpio_init();
void timer_nvic_init();
void timer_pwm_init();
void adc_init();
void adc_leds_init();
void usart_init();
