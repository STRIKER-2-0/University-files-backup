import java.util.Scanner;

public class Equation {

    public static void main (String[] args) {
        int N;
        Scanner scanner = new Scanner(System.in);
        System.out.print("Введите число N: ");
        N = scanner.nextInt();
        Summa(N);
    }

    public static double Summa (int n) {
        double result = 0;

        for (int i = 1; i <= n; i++) {
            result += (Math.pow(-1,i))/(Math.pow((2 * i + 1), i));
        }
        System.out.println("Сумма: " + result);
        return Math.floor(result);
    }
}
