import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class TestEquation {
    private Equation equation;

    @Before
    public void init() {
        equation = new Equation();
    }

    @After
    public void tearDown() {
        equation = null;
    }

    @Test
    public void findSumma() {
        assertTrue(equation.Summa(1) == (-1.0));
    }

    @Test
    public void findSumma1() {
        assertTrue(equation.Summa(2) == (-1.0));
    }
}
