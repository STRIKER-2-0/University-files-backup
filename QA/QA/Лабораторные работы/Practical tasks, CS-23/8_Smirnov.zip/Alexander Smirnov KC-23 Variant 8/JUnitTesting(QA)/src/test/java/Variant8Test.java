import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class Variant8Test {
    Variant8 rows = new Variant8();
    private double e,result;
    private int k;
    private int numIter;
    private double num;
    @Before
    public void initTest(){
        e = 0.001;
        numIter = 0;
        result = 0;
        num=-1;
    }
    @Test
    public void testSetE() {
        double result=e;
        assertEquals(new Double(e), new Double(result));
    }
    @Test
    public void testNumIter() {
        rows.rowsSum(e);
        int i=0;
        int factorial=1;
        while (Math.abs(num)>e){

            num=(Math.pow(-2,i))/(factorial);
            if (Math.abs(num) < e) {
                break;
            }
            result+=num;
            i++;
            numIter++;
            factorial*=i;
            System.out.println(result);
        }
        Assert.assertTrue(rows.numIter==numIter);
    }
    @Test
    public void testRowsSum() {
        int i=0;
        int factorial=1;
        while (Math.abs(num)>e){

            num=(Math.pow(-2,i))/(factorial);
            if (Math.abs(num) < e) {
                break;
            }
            result+=num;
            i++;
            numIter++;
            factorial*=i;
            System.out.println(result);
        }
        rows.rowsSum(e);
        Assert.assertTrue(rows.result==result);
    }
}