import java.util.ArrayList;
import java.util.Scanner;

public class Variant8 {
    public double e,result=0;

    public int numIter=0;
    public double num=-1;
    public double factorial;

    public void setE(){
        do {
            System.out.print("Enter E:");
            Scanner scanner = new Scanner(System.in);
            e=scanner.nextDouble();
        }while(e<0);
    }

    public double getE(){
        return e;
    }

    public void rowsSum(double e){
        int i=0;
        factorial=1;
        while (Math.abs(num)>e){

            num=(Math.pow(-2,i))/(factorial);
            if (Math.abs(num) < e) {
                break;
            }
            result+=num;
            i++;
            numIter++;
            factorial*=i;
            System.out.println(result);
        }
    }

    public int getNumIter(){
        return numIter;
    }

    public static void main(String[] args) {
        Variant8 rows = new Variant8();
        rows.setE();
        System.out.println("Сумма последовательности на каждой итерации: ");
        rows.rowsSum(rows.e);
        System.out.println("Количество итераций: "+rows.getNumIter());
        System.out.println("Текущее значение слагаемого: "+rows.num);
        System.out.println("Сумма последовательности: "+rows.result+ " с заданой точностью : E = "+rows.getE());
    }
}

