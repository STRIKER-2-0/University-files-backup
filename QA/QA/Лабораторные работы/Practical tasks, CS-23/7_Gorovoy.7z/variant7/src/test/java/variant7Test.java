import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import static java.lang.Math.abs;
import static org.junit.Assert.*;

public class variant7Test {
    variant7 variant7 = new variant7();
    private double e, sum;
    private int count;

    @Before
    public void initTest() {
        e = 0.01;
        sum = 0;
        count = 0;
    }

    @Test
    public void testSetE() {
        double sum = e;
        assertEquals(new Double(e), new Double(sum));
    }

    @Test
    public void testSum() {
        variant7.countSum(e);
        int k = 1;
        double riad = ((Math.pow(-1, k)) / ((2 * k + 1) * k));
        sum = riad;
        while (e <= abs(riad)) {
            k++;
            count++;
            riad = ((Math.pow(-1, k)) / (((2 * k) + 1) * k));
            sum += riad;
        }
        double result = variant7.sum;
        Assert.assertTrue(result == sum);
    }
    @Test
    public void testIter(){
        variant7.countSum(e);
        int k = 1;
        double riad = ((Math.pow(-1, k)) / ((2 * k + 1) * k));
        sum = riad;
        while (e <= abs(riad)) {
            k++;
            count++;
            riad = ((Math.pow(-1, k)) / (((2 * k) + 1) * k));
            sum += riad;
        }
        double result = variant7.count;
        Assert.assertTrue(result == count);
    }
}
