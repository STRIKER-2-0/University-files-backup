import java.util.Scanner;

import static java.lang.Math.abs;

public class variant7 {
    int count=0;
    double sum;
    public void countSum(double e){
        int k=1;
        double riad=((Math.pow(-1,k))/((2*k+1)*k));
        sum=riad;
        while(e<=abs(riad)){
            k++;
            count++;
            riad = ((Math.pow(-1, k)) / (((2 * k) + 1) * k));
            sum+=riad;
            System.out.println(sum);
            System.out.println(riad);
        }
        System.out.println(sum);
        System.out.println(count);
    }
    public static void main(String[] args) {
        variant7 variant7=new variant7();
        double e;
        do {
            System.out.print("Enter E:");
            Scanner scanner = new Scanner(System.in);
            e=scanner.nextDouble();
        }while(e<=0);
        variant7.countSum(e);

    }
}