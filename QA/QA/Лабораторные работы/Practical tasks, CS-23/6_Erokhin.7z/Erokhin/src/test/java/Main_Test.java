import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class Main_Test {
    Main rows = new Main();
    private double e,sum;
    private int k;
    private double term;
    @Before
    public void initTest(){
        e = 0.001;
        k = 1;
        sum = 0;
        term=1/(Math.pow((2*1+1),2));
    }

    @Test
    public void testSetE() {
        double result=e;
        assertEquals(new Double(e), new Double(result));
    }

    @Test
    public void testRowsSum() {
        while (Math.abs(term)>e){
            term=1/(Math.pow((2*k+1),2));
            if (Math.abs(term) < e) {
                break;
            }
            sum+=term;
            k++;
        }
        rows.rowsSum(e);
        Assert.assertTrue(rows.sum == sum);
    }
}