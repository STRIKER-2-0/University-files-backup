import java.util.Scanner;

public class Main {
    public double e,sum=0;
    public int k = 1;
    public double term=1/(Math.pow((2*1+1),2));

    public void setE(){
            System.out.print("Enter E: ");
            Scanner scanner = new Scanner(System.in);
            e=scanner.nextDouble();
    }

    public double getE(){
        return e;
    }

    public void rowsSum(double e){
        while (Math.abs(term)>e){
            term=1/(Math.pow((2*k+1),2));
            if (Math.abs(term) < e) {
                break;
            }
            sum+=term;
            k++;
            System.out.println(sum);
        }
    }

    public static void main(String[] args) {
        Main rows = new Main();
        rows.setE();
        rows.rowsSum(rows.e);
        System.out.println("Term of rows : " + rows.term);
        System.out.println("Sum of rows : " + rows.sum);
    }
}

