import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Calculator calc = new Calculator();
        System.out.println("Enter N");
        Scanner scn = new Scanner(System.in);
        int n;
        while ((!scn.hasNextInt())) {
            System.out.println("Ошибка ввода. Повторите");
            scn.next();
        }
        n = scn.nextInt();
        BigDecimal summa = calc.Summ(n);

        System.out.println("*********" + summa);

    }

}
