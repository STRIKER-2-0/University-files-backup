import java.math.BigDecimal;
import java.math.RoundingMode;

public class Calculator {

    public BigDecimal Summ(int n){
        double summ = 0;
        for (int k=1; k<= n; k++){
            double element = (Math.pow(-1, k))/((2*k+1)*k);
            summ=summ+element;
        }
        BigDecimal big = BigDecimal.valueOf(summ);
        return big.setScale(5, RoundingMode.HALF_UP);
    }
}
