import org.junit.Assert;
import org.junit.Test;

import java.math.BigDecimal;

import static org.junit.Assert.*;

public class CalculatorTest {
Calculator calc = new Calculator();
    @Test
    public void summ() {
        BigDecimal result = calc.Summ(5);
        BigDecimal expected = BigDecimal.valueOf(-0.27136);
        System.out.println("Expected:"+expected+"\nActual:"+result);
        Assert.assertEquals(expected, result);
    }
}