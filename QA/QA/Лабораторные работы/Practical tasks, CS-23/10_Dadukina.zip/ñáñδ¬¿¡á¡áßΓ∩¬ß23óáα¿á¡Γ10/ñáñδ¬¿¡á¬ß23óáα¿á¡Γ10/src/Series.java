public class Series {

    public double FunctionF(int x) {
        double E=0.000001;
        double elem=1;
        double sum=0;
        for (int k=0;Math.abs(elem)>E;k++){
            elem=Math.pow((-1),k+1)*((Math.pow(2,2*k-1)*(Math.pow(x,2*k))/factorial(2*k)));
            sum+=elem;
        }
        return sum;
    }

    public double FunctionS(int x){
        return FunctionF(x)-Math.pow(Math.sin(x),2);
    }

    public int factorial (int n){
        int result=1;
        if (n==1||n==0){
            return result;
        }
        result=n*factorial(n-1);
        return result;
    }

    public static void main(String[] args) {
        Series k = new Series();
        for (int x = 0; x < 11; x++) {
            System.out.println(k.FunctionS(x));
        }
    }
}
