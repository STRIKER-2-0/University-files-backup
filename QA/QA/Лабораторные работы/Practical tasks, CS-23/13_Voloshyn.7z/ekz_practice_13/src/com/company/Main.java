package com.company;

public class Main {
    public static void main(String[] args) {
	    double E = -0.0001, x0 = 0, x1 = 0.8, x = 0.1, F=0, S;
	    int k = 0;
	    System.out.println(SF(x0, x1, x, F, k));

    }
    public static double SF( double x0, double x1 , double x , double F, int k){
        double S = 0;
        while(x0<x1){
            k++;
            F += Math.pow(-1, k + 1) * k * Math.pow(x, k - 1)*nado(k);
            x0+=x;
        }
        x0=0;

        S = F - ((1-Math.log(1+x0))/Math.pow(1+x0, 2));
        return Math.round(S * 10000.0) / 10000.0;
    }
    public static double nado(int K){
        double sum = 0;
        for(int n = 1; n<=K; n++){
            sum = sum + 1/n;
        }
        return sum;
    }
}
