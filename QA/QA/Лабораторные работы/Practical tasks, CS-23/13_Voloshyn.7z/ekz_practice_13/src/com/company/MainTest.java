package com.company;

import org.junit.After;
import org.junit.Before;

import static org.junit.Assert.*;

public class MainTest {
    private Main series;

    @Before
    public void init() {
        series = new Main();
    }

    @After
    public void tearDown() {
        series = null;
    }


    @org.junit.Test
    public void findSum() {
        assertTrue(series.SF(0, 0.8, 0.1, 0, 0 ) == (-0.1736));
    }
}
