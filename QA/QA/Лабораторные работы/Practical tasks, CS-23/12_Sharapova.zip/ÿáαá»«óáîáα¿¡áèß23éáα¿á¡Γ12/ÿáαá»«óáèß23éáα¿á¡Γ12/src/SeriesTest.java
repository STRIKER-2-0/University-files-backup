import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertTrue;

public class SeriesTest {
    private Series series;

    @Before
    public void init() {
        series = new Series();
    }

    @After
    public void tearDown() {
        series = null;
    }


    @Test
    public void findSum() {
        assertTrue(series.FunctionS(1) == (-4.0));
        
    }
}

