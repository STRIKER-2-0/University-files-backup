public class Series {

    public int factorial(int n) {

        if ( n == 0) {
            return 1;
        } else
            return   (n * factorial(n - 1));

    }

    public double FunctionF(int x) {
        double E = 0.000001;
        double elem = 1;
        double sum = 0;

        for (int k = 0; Math.abs(elem) > E; k++) {
            elem = Math.pow((-1), k) * ((Math.pow(3, 2 * k) + 3) / factorial(2 * k)) * Math.pow(x, 2 * k + 1);
            sum += elem;
        }
        return sum;

    }

    public double FunctionS(int x) {
        return FunctionF(x) - 4 * Math.pow(Math.cos(x), 3);
    }

        public static void main(String[] args) {
            Series k = new Series();
            for (int x = 0; x < 11; x++) {
                System.out.println(k.FunctionS(x));
            }
        }
    }
