import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class FunctionTabulationTest {

    private FunctionTabulation functionTabulation;

    @Before
    public void beforeTests() {
        functionTabulation = new FunctionTabulation();
    }

    @Test
    public void calculationPartFTest() {
        assertEquals(120.0, Math.round(functionTabulation.factorial(5)), 0.0);
    }

    @Test
    public void calculationFTest() {
        assertEquals(1.7080734198194518, functionTabulation.calculationF(1.0), 0.0);
    }

    @Test
    public void calculationSTest() {
        assertEquals(9.999999936707786, functionTabulation.calculationS(), 0.0);
    }
}