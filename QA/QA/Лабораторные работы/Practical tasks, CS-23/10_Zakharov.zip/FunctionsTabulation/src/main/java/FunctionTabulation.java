public class FunctionTabulation {

    private double e = 0.000001;
    private double xBegin = 0.0;
    private double xEnd = 10.0;
    private double step = 1.0;

    public static void main(String[] args) {
        FunctionTabulation functionTabulation = new FunctionTabulation();
        double result = functionTabulation.calculationS();
        System.out.printf("\nFinal result = %.6f\n", result);
    }

    public double calculationS() {
        double result = 0.0;
        System.out.println("\t\t x\t\t S(x)");
        for (double x = xBegin; x <= xEnd; x += step) {
            result = calculationF(x) - Math.pow(Math.sin(x), 2.0);
            System.out.printf("\t\t%.1f", x);
            System.out.printf("\t\t%.6f\n", result);
        }
        return result;
    }

    public double calculationF(double x) {
        double current = 1.0 * x;
        double previous = 0.0;

        int k = 1;
        while ((Math.abs(current - previous)) >= e) {
            previous = current;
            current += Math.pow(-1.0, k + 1.0) * ((Math.pow(2.0, 2.0 * k - 1.0) * Math.pow(x, 2.0 * k)) / (factorial(2.0 * k)));
            k++;
        }
        return current;
    }

    public double factorial(double k) {
        double result = 1.0;
        for (double i = 1.0; i <= k; i++) {
            result *= i;
        }
        return result;
    }

}
