package com.app;

import org.junit.Test;
import static org.junit.Assert.assertFalse;

public class FormulaOperationsTest {

    @Test
    public void calculateSum() {
        FormulaOperations operations = new FormulaOperations();
        double e = 0.07;
        System.out.println("e = "+e);
        boolean actual = operations.calculateSum(e);
        assertFalse(actual);
        System.out.println("Result of execution. Sum of row < E -> "+actual);
    }
}