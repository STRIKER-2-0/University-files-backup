package com.app;

import java.math.BigDecimal;
import java.math.RoundingMode;

import static java.lang.Math.abs;

class FormulaOperations {

    private double calculateCurrent(int k){   //результат вычисления k-го члена ряда.
        var b =((Math.pow(-1, k))/((2*k+1)*k));
        var value = BigDecimal.valueOf(b).setScale(5, RoundingMode.HALF_UP);
        System.out.println("current value = "+value+" with k = "+k);

        return value.doubleValue();
    }

    boolean calculateSum(double e){

        boolean done = true;
        double current = 0;   // значение текущего члена ряда,
        double sum = 0;       // сумма ряда
        int k = 1;            // номер текущего члена ряда (число k)

        while ((abs(sum) < e)||k!=50){
            k++;
            current = calculateCurrent(k);
            sum = sum+current;

            System.out.println("****Sum = "+sum);
            if (k==50 || (abs(sum) > e)) {
                done = false;
                break;
            }
        }

        return done;
    }
}
