package com.app;
import java.util.Scanner;

public class App {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("1) Get average \n2) Exit");
            int choice = sc.nextInt();
            switch (choice) {
                case 1 :{
                    System.out.println("enter size of precision");
                    double e = sc.nextDouble();
                    FormulaOperations operations = new FormulaOperations();
                    System.out.println("Result of execution. Sum of row < E \n"+ operations.calculateSum(e));
                    return;
                }
                case 2 : {
                    System.out.println("buy!");
                    return;
                }
                default : {
                    System.out.println("wrong!");
                }
            }

        }
    }
}
