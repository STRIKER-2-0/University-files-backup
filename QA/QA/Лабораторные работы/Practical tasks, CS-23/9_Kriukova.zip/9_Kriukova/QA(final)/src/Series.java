import java.util.Scanner;

public class Series {

    public static double findSum(double e) {
        int i = 1;
        double result = 0, newAddend;
        while (true) {
            newAddend = 1 / (double) (i * (i + 1));
            System.out.println("\n" + newAddend);
            if(Math.abs(newAddend) < e){
                break;
            }
            result += newAddend;
            i++;
           System.out.format("result = " + "3%f", result);

        }
        return Math.ceil(result);
    }

    public static void main(String[] args) {
        double E;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter E");
        E = sc.nextDouble();
        findSum(E);
    }
}
