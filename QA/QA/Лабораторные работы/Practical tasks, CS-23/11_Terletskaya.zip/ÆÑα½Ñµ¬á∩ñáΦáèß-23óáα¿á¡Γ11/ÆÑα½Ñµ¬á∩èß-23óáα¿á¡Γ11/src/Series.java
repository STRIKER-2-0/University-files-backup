public class Series {
    public double FunctionF(int x) {
        double E=0.000001;
        double elem=1;
        double sum=0;
        for (int k=0;Math.abs(elem)>E;k++){
            elem=Math.pow((-1),k+1)*((Math.pow(3,2*k+1)-3)/(factorial(2*k+1))*Math.pow(x,2*k+1));
            sum+=elem;
        }
        return sum;
    }

    public double FunctionS(int x){
        return FunctionF(x)-4*Math.pow(Math.sin(x),3);
    }

    public int factorial (int n){
        int result=1;
        if (n==1||n==0){
            return result;
        }
        result=n*factorial(n-1);
        return result;
    }


    public static void main(String[] args) {
        Series k = new Series();
        for (int x=0; x<0.9;x++){
            System.out.println("Получаем: "+k.FunctionS(x));
        }
    }
}