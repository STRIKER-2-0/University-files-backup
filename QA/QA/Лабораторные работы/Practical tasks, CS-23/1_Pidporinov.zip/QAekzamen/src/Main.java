import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        int N = 0;
        do {
            System.out.print("Задайте натуральное число N: N=");
            Scanner input = new Scanner(System.in);
            N = input.nextInt();
        } while (N <= 0);

        System.out.println("Вычисление ряда с точностью E = 10^(-4): " + calculate(N));
    }

    private static double calculate(int N) {
        double a = 0;
        for (int k = 1; k <= N; k++) {
            a = a + Math.pow(-1,k)/Math.pow( (2 * k + 1), 2);
        }
        a = Math.round(a * 10000.00) / 10000.00;
        return a;
    }
}
