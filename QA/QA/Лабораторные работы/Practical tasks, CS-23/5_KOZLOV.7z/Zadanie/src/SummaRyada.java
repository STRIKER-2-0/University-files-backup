import static com.sun.corba.se.impl.util.Utility.printStackTrace;

public class SummaRyada{
    public static double solveSummary(int N){
        double result=0;
            for (int i = 1; i <=N; i++) {
            result+= factrorial(i)/((1/2)+(1/3)+(1/i+1));
            }
            System.out.print(result);
        return result;
        }
    public static long factrorial(long n) {
        if (n <= 1)
            return 1;
        else
            return n * factrorial(n - 1);
        }
    public static void main (String[] args) {

        int N=6;
        System.out.print("Summa ryada ot 1 do " + N + " = ");
            solveSummary(N);
        System.out.println();
        N=3;
        System.out.print("Summa ryada ot 1 do " + N + " = ");
        solveSummary(N);
        System.out.println();
        N=9;
        System.out.print("Summa ryada ot 1 do " + N + " = ");
        solveSummary(N);
        System.out.println();
        }

}
