import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class SummaTest {
    private SummaRyada sr;
    @Before
    public void init() {
        sr = new SummaRyada();
    }

    @Test

        public void summaryTest1() {
            assertTrue(sr.solveSummary(3) == (8.0));
        }
        @Test
        public void summaryTest2() {
            System.out.println();
            assertTrue(sr.solveSummary(9) == 409112.0);
        }
        @Test
        public void summaryTest3() {
            System.out.println();
            assertTrue(sr.solveSummary(6) == 872.0);
        }
    @After
    public void tearDown(){
        sr = null;
    }

}