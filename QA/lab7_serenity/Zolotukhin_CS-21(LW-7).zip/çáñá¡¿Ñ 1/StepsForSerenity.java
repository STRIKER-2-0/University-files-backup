import Pages.ComputerPage;
import Pages.HomePage;
import net.thucydides.core.annotations.Step;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import static org.assertj.core.api.Assertions.assertThat;


public class StepsForSerenity {
    public HomePage homePage;
    public WebDriver driver;
    public ComputerPage computerPage;
    public String siteHomePage = "https://pn.com.ua/";

    @Step("Given the user visits a page {0}")
    public void a_user_visits_a_page(String page){
        this.siteHomePage = page;
    }

    @Step("When the user chooses category Computer {0}")
    public void a_user_chooses_category_computer(){
        driver = new ChromeDriver();
        homePage = new HomePage(driver);
        driver.get(siteHomePage);
        computerPage = homePage.choiceComputerCategory();
    }

    @Step("Then the user sees {0} subcategory")
    public void a_user_can_see_subcategory_ITService(String subcategory){
        assertThat(computerPage.getTextITService()).overridingErrorMessage("testComputerCategory failed").contains(subcategory);
        driver.close();
    }
}
