import net.serenitybdd.junit.runners.SerenityRunner;
import net.thucydides.core.annotations.Steps;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(SerenityRunner.class)
public class MainTest {
    String homePath = "https://pn.com.ua/ct/1043/";

    @Steps
    StepsForSerenity stepsForSerenity;

    @Test
    public void verify_to_elements() throws InterruptedException {
        stepsForSerenity.a_user_visits_a_page(homePath);
        stepsForSerenity.a_user_chooses_two_elements();
        stepsForSerenity.a_user_can_see_two_elements("2 модели");
    }
}
