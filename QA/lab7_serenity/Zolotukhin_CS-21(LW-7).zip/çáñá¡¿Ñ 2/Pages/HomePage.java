package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage {
    private WebDriver driver;

    public HomePage(WebDriver driver){
        this.driver = driver;
        PageFactory.initElements(driver,this);
    }

    @FindBy(xpath = ".//*[@id='column-center']/section/div[3]/article[1]/div[2]/div[3]/span[2]/a")
    WebElement first_element;

    @FindBy(xpath = ".//*[@id='column-center']/section/div[3]/article[2]/div[2]/div[3]/span[2]/a")
    WebElement second_element;

    @FindBy(xpath = ".//*[@id='column-center']/section/div[1]/div[1]/a")
    WebElement compare_button;

    public void add_first_element(){
        first_element.click();
    }

    public void add_second_element(){
        second_element.click();
    }

    public ComparePage click_compare_button(){
        compare_button.click();
        return  new ComparePage(driver);
    }
}
