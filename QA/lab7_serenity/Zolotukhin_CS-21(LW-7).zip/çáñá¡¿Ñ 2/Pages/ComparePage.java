package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ComparePage {
    private WebDriver driver;

    public ComparePage(WebDriver driver){
        this.driver = driver;
        PageFactory.initElements(driver,this);
    }

    @FindBy(xpath = "html/body/div[1]/div[2]/div/div/div[1]/ul/li[4]/small")
    private WebElement compare_list;

    public String getTextCompareList(){
        return compare_list.getText();
    }

    public String getURL(){
        return driver.getCurrentUrl();
    }
}
