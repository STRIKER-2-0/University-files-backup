import Pages.ComparePage;
import Pages.HomePage;
import net.thucydides.core.annotations.Step;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import static org.assertj.core.api.Assertions.assertThat;

public class StepsForSerenity {
    public HomePage homePage;
    public WebDriver driver;
    public ComparePage comparePage;
    public String path = "https://pn.com.ua/ct/1043/";



    @Step("Given the user visits a page")
    public void a_user_visits_a_page(String page){
        this.path = page;
        driver = new ChromeDriver();
        driver.get(page);
        homePage = new HomePage(driver);
    }

    @Step("When user chose two elements and click compare")
    public void a_user_chooses_two_elements() throws InterruptedException {
        homePage.add_first_element();
        Thread.sleep(1000);
        homePage.add_second_element();
        Thread.sleep(1000);
        comparePage = homePage.click_compare_button();
        Thread.sleep(1000);
    }

    @Step("Then user sees two elements")
    public void a_user_can_see_two_elements(String str){
        assertThat(comparePage.getTextCompareList()).overridingErrorMessage("test two elements failed").contains(str);
        driver.close();
    }




}
